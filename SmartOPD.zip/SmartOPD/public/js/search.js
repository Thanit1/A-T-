const socket = io();

// ตัวแปรสำหรับจัดการการค้นหา
let isProcessing = false;
let lastSearchValue = '';
let debounceTimer = null;

// เพิ่มตรงส่วนบนของไฟล์
const beforeMeasureSound = new Audio('/sounds/ก่อนวัด.mp3');

function playLimitedSound() {
    beforeMeasureSound.play();
    
    // หยุดเสียงหลังจาก 2.5 วินาที
    setTimeout(() => {
        beforeMeasureSound.pause();
        beforeMeasureSound.currentTime = 0;
    }, 2490);
}

// ฟังก์ชันสำหรับการค้นหา
function searchPatient(searchValue) {
    if (searchValue === lastSearchValue || isProcessing || !searchValue.trim()) {
        return;
    }

    isProcessing = true;
    lastSearchValue = searchValue;

    socket.emit('searchPatients', searchValue);

    setTimeout(() => {
        isProcessing = false;
    }, 1000);
}

// ฟังก์ชันสำหรับ focus input
function focusSearchInput() {
    const searchInput = document.getElementById('searchValue');
    if (searchInput) {
        // ถ้าเป็นการโหลดหน้าใหม่ ไม่ต้องเคลียร์ค่า
        if (searchInput.value) {
            searchInput.select(); // เลือกข้อความทั้งหมดถ้ามี
        }
        searchInput.focus();
    }
}

// Event Listeners สำหรับการค้นหา
document.getElementById('searchValue').addEventListener('input', function(e) {
    const searchValue = e.target.value.trim();
    
    if (debounceTimer) {
        clearTimeout(debounceTimer);
    }
    
    if (searchValue.length >= 2) {
        debounceTimer = setTimeout(() => {
            searchPatient(searchValue);
        }, 300);
    }
});

document.getElementById('searchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const searchValue = document.getElementById('searchValue').value.trim();
    
    if (!searchValue) {
        alert('กรุณาระบุคำค้นหา');
        return;
    }
    
    searchPatient(searchValue);
});

// ฟังก์ชันแสดงข้อมูลคนไข้
function displayPatient(patient) {
    const patientList = document.getElementById('patientList');
    patientList.innerHTML = '';
    
    if (!patient) {
        patientList.innerHTML = `
            <div class="list-group-item text-center">ไม่พบข้อมูล</div>
        `;
        return;
    }
    
    const birthDate = new Date(patient.thai_birthday);
    const thaiDate = birthDate.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    // สร้าง card สำหรับแสดงข้อมูลผู้ป่วย
    const patientCard = document.createElement('div');
    patientCard.className = 'card shadow-sm';
    patientCard.innerHTML = `
        <div class="card-body text-center p-3">
            <h1 class="patient-name text-dark">
                ชื่อ-สกุล: <span class="text-primary fw-bold">${patient.patient_name || '-'}</span>
            </h1>
            <div class="row justify-content-center g-4">
                <div class="col-6">
                    <div class="info-badge badge bg-light text-dark fw-bold">
                        <i class="bi bi-person-vcard info-icon"></i>
                        HN: ${patient.hn || '-'}
                    </div>
                </div>
                <div class="col-6">
                    <div class="info-badge badge bg-light text-dark fw-bold">
                        <i class="bi bi-clipboard2-pulse info-icon"></i>
                        VN: ${patient.vn || '-'}
                    </div>
                </div>
                <div class="col-6">
                    <div class="info-badge badge bg-light text-dark fw-bold">
                        <i class="bi bi-calendar-event info-icon"></i>
                        อายุ: ${patient.age || '-'} ปี
                    </div>
                </div>
                <div class="col-6">
                    <div class="info-badge badge bg-light text-dark fw-bold">
                        <i class="bi bi-calendar3 info-icon"></i>
                        วันเกิด: ${thaiDate || '-'}
                    </div>
                </div>
            </div>
        </div>
    `;
    patientList.appendChild(patientCard);

    // เล็บข้อมูลผู้ป่วยและเริ่มต้นการวัด
    if (patient) {
        const patientData = {
            hn: patient.hn,
            vn: patient.vn,
            patientName: patient.patient_name
        };
        
        // เก็บข้อมูลใน localStorage
        localStorage.setItem('currentPatient', JSON.stringify(patientData));
        
        // เริ่ม session ใหม่
        socket.emit('initSession', {
            hn: patient.hn,
            vn: patient.vn
        });
    }

    // เลียกใช้ฟังก์ชันเล่นเสียงแบบจำกัดเวลา
    playLimitedSound();

    // สร้าง card สำหรับแสดงการนับถอยหลัง
    const countdownCard = document.createElement('div');
    countdownCard.className = 'card border-primary';
    countdownCard.innerHTML = `
        <div class="card-body text-center p-4">
            <div class="countdown-display">
                <h3 class="text-primary countdown-text mb-0"></h3>
            </div>
        </div>
    `;
    patientList.appendChild(countdownCard);

    // เริ่มการนับถอยหลัง
    const countdownText = countdownCard.querySelector('.countdown-text');
    let countdown = 3;

    // ขอการตั้งค่าจาก server เพียงครั้งเดียว
    socket.emit('getDisplayConfig', (config) => {
        const firstEnabledPage = config.order.find(page => config.enabled[page]);
        
        if (firstEnabledPage) {
            const countdownInterval = setInterval(() => {
                countdown--;
                countdownText.textContent = `กำลังไปหน้าถัดไปในอีก ${countdown} วินาที...`;
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = `/next-page?from=search`;
                }
            }, 1000);
        } else {
            countdownText.textContent = 'ไม่พบหน้าที่เปิดใช้งาน';
        }
    });
}

// Event Listeners สำหรับการแสดงผลการค้นหา
socket.on('patientFound', (patient) => {
    displayPatient(patient);
    
    // บันทึกข้อมูลผู้ป่วย
    socket.emit('updateReadings', {
        type: 'patient',
        value: {
            hn: patient.hn,
            vn: patient.vn,
            patientName: patient.patient_name
        }
    });
});

socket.on('patientNotFound', (message) => {
    const tbody = document.getElementById('patientList');
    tbody.innerHTML = `
    <div class="card-body text-center p-5">
            <div class="alert alert-warning shadow-sm rounded-3 border" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 text-warning fs-2"></i>
                <h1 class="patient-name text-dark mb-0 mt-3">
                    <span class="text-primary fw-bold">${message || '-'}</span>
                </h1>
                <small class="text-muted mt-2 d-block">กรุณาลองค้นหาใหม่อีกครั้ง</small>
            </div>
    </div>
        
    `;
    setTimeout(focusSearchInput, 500);
});

// การจัดการ card reader
socket.on('cardInserted', (data) => {
    const searchInput = document.getElementById('searchValue');
    searchInput.value = data.cid;
    searchPatient(data.cid);
});

// โพิ่มฟังก์ชันสำหรับการโหลดเสียงล่วงหน้า
function preloadSound() {
    beforeMeasureSound.load();
}

// เรียกใช้ preloadSound เมื่อโหลดหน้าเว็บ
document.addEventListener('DOMContentLoaded', preloadSound);

// เพิ่ม socket listener สับเคลียร์ข้อมูล
socket.on('clearPatientData', () => {
    localStorage.removeItem('currentPatient');
});

// เพิ่มฟัวแปรสำหรับเก็บการตั้งค่า
let welcomeSettings = {
    hospitalName: 'โรงพยาบาลกรุงเทพ',
    welcomeImage: '/images/1.webp'
};

// รับการตั้งค่าใหม่
socket.on('welcomeSettingsUpdated', (settings) => {
    if (settings) {
        welcomeSettings = settings;
        showWelcome(); // แสดงหน้าต้อนรับใหม่ทันที
    }
});

function showWelcome() {
    const patientList = document.getElementById('patientList');
    
    const timestamp = new Date().getTime();
    const welcomeImage = welcomeSettings?.welcomeImage 
        ? `${welcomeSettings.welcomeImage}?t=${timestamp}`
        : '/images/1.webp';
    
    patientList.innerHTML = `
        <div class="welcome-container text-center">
            <img src="${welcomeImage}" alt="ยินดีต้นรับ" class="welcome-image mb-4" 
                 onerror="this.src='/images/1.webp'"
                 onload="console.log('โหลดรูปภาพสำเร็จ:', this.src)">
            <h2 class="welcome-text mb-3">
                <span class="hospital-name">${welcomeSettings?.hospitalName || 'โรงพยาบาลกรุงเทพ'}</span>
                <br>
                <span class="welcome-word">ยินดีต้อนรับ</span>
            </h2>
            <p class="welcome-description">
                กรุณาค้นหาผู้ป่วยด้วย HN, เลขบัตรประชาชน หรือ VN
            </p>
        </div>
    `;
}

// แก้ไขการโหลดการตั้งค่าเริ่มต้น
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // ขอข้อมูลการตั้งค่าจาก server
        const response = await fetch('/api/welcome-settings');
        const data = await response.json();
        
        if (data.success && data.settings) {
            welcomeSettings = data.settings;
        }
    } catch (error) {
        console.error('Error loading welcome settings:', error);
    } finally {
        showWelcome(); // แสดงหน้าต้อนรับไม่ว่าจะโหลดสำเร็จหรือไม่
    }

    // ขอข้อมูล IP จาก server
    socket.emit('getServerIP');
});

// เพิ่มต่อจาก socket listeners ที่มีอยู่
socket.on('serverIP', (ip) => {
    document.getElementById('serverIP').textContent = `Server IP: ${ip}`;
});

// เพิ่มการโฟกัส input เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    // โฟกัสที่ input ทันที
    focusSearchInput();
    
    // ขอข้อมูล IP จาก server
    socket.emit('getServerIP');
    
    // โหลดเสียงล่วงหน้า
    preloadSound();
});

// เพิ่มตัวแปรสำหรับจัดการเวลา
let inactivityTimer;
let screensaverTimer;
let lastActivityTime = Date.now();

// ฟังก์ชันสำหรับเคลียร์ค่หลังจาก 30 วินาที
function clearSearchAfterInactivity() {
    const searchInput = document.getElementById('searchValue');
    const patientList = document.getElementById('patientList');
    if (searchInput) {
        searchInput.value = '';
    }
    if (patientList) {
        showWelcome(); // แสดงหน้า welcome กับมา
    }
}

// ฟังก์ชันสำหรับรีเซ็ตตัวจับเวลา
function resetTimers() {
    lastActivityTime = Date.now();
    
    // ยกเลิกตัวจับเวลาเดิม
    clearTimeout(inactivityTimer);
    clearTimeout(screensaverTimer);
    
    // ตยุดและซ่อน screensaver ถ้ากำลังแสดงอยู่
    hideScreensaver();
    
    // ตั้งตัวจับเวลาใหม่
    inactivityTimer = setTimeout(() => {
        clearSearchAfterInactivity();
    }, 30000); // 30 วินาที
    
    screensaverTimer = setTimeout(() => {
        showScreensaver();
    }, 60000); // 1 นาที
}

let hasUserInteracted = false; // เพิ่มตัวแปรเพื่อเช็คว่าผู้ใช้ได้ interact แล้วหรือยัง

// เพิ่ม event listener สำหรับตรวจจับการ interact ครั้งแรก
document.addEventListener('click', function initAudio() {
    hasUserInteracted = true;
    document.removeEventListener('click', initAudio);
}, { once: true });

// เพิ่มฟังก์ชันสำหรับจำลองการ interact
function simulateUserInteraction() {
    // สร้าง event click เพื่อจำลองการ interact ของผู้ใช้
    const event = new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true
    });
    document.dispatchEvent(event);
    hasUserInteracted = true;
}

async function showScreensaver() {
    try {
        // จำลองการ interact ก่อนเล่นวิดีโอ
        simulateUserInteraction();
        
        const response = await fetch('/api/videos');
        const data = await response.json();
        
        if (!data.success || !data.videos || data.videos.length === 0) {
            console.error('ไม่พบไฟล์วิดีโอ');
            return;
        }

        // สร้าง screensaver container
        const screensaver = document.createElement('div');
        screensaver.className = 'screensaver';
        screensaver.innerHTML = `
            <div class="video-wrapper">
                <video class="screensaver-video" playsinline>
                    <source src="/videos/${data.videos[0]}" type="video/mp4">
                </video>
            </div>
            <div class="instruction-text">
                <i class="bi bi-qr-code me-2"></i>กรุณาแสกน QR Code หรือเสียบบัตรประชาชน
            </div>
        `;

        document.body.appendChild(screensaver);
        
        const video = screensaver.querySelector('.screensaver-video');
        let currentVideoIndex = 0;

        // แก้ไขฟังก์ชันเล่นวิดีโอ
        const playVideo = async () => {
            try {
                video.muted = false;
                video.volume = 1;
                await video.play();
            } catch (error) {
                console.log('พยายามเล่นวิดีโอแบบมีเสียงอีกครั้ง:', error);
                // ถ้าเล่นไม่ได้ ให้ลองเล่นแบบปิดเสียงก่อน แล้วค่อยเปิดเสียง
                video.muted = true;
                try {
                    await video.play();
                    // หลังจากเล่นได้แล้ว รอสักครู่แล้วเปิดเสียง
                    setTimeout(() => {
                        video.muted = false;
                        video.volume = 1;
                    }, 500);
                } catch (secondError) {
                    console.log('ไม่สามารถเล่นวิดีโอได้:', secondError);
                }
            }
        };

        // เล่นวิดีโอแรก
        await playVideo();

        // เมื่อวิดีโอเล่นจบ
        video.addEventListener('ended', async () => {
            currentVideoIndex++;
            if (currentVideoIndex >= data.videos.length) {
                currentVideoIndex = 0;
            }
            video.src = `/videos/${data.videos[currentVideoIndex]}`;
            await playVideo();
        });

    } catch (error) {
        console.error('เกิดข้อผิดพลาดในการโหลดวิดีโอ:', error);
    }
}

// แก้ไขฟังก์ชัน hideScreensaver
function hideScreensaver() {
    const screensaver = document.querySelector('.screensaver');
    if (screensaver) {
        const video = screensaver.querySelector('video');
        if (video) {
            video.pause();
            video.currentTime = 0;
        }
        screensaver.remove();
        document.body.classList.remove('screensaver-active');
    }
}

// เพิ่ม event listeners สำหรับตรวจจับการเคลื่อนไหว
document.addEventListener('mousemove', resetTimers);
document.addEventListener('keypress', resetTimers);
document.addEventListener('click', resetTimers);
document.addEventListener('touchstart', resetTimers);
document.addEventListener('scroll', resetTimers);

// อัพเดท CSS
const style = document.createElement('style');
style.textContent = `
    .screensaver {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: black;
        z-index: 9999;
        display: flex;
        justify-content: center;
        align-items: center;
        animation: fadeIn 0.5s ease-in;
    }
    .screensaver-video {
        width: 100%;
        height: 100%;
        object-fit: cover;
        position: absolute;
        top: 0;
        left: 0;
        transition: opacity 0.5s ease-in-out;
    }
    .instruction-text {
        position: fixed;
        bottom: 40px;
        left: 50%;
        transform: translateX(-50%);
        color: white;
        background: rgba(0, 0, 0, 0.7);
        padding: 15px 30px;
        border-radius: 30px;
        font-size: 1.5rem;
        z-index: 10000;
        text-align: center;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(5px);
        animation: float 2s ease-in-out infinite;
    }
    @keyframes float {
        0%, 100% {
            transform: translateX(-50%) translateY(0px);
        }
        50% {
            transform: translateX(-50%) translateY(-10px);
        }
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    /* สำหรับหน้าจอขนาด 600x1024 */
    @media screen and (width: 600px) and (height: 1024px) {
        .instruction-text {
            font-size: 1.2rem;
            padding: 12px 24px;
            bottom: 30px;
        }
    }
`;
document.head.appendChild(style);

// แก้ไข DOMContentLoaded event
document.addEventListener('DOMContentLoaded', () => {
    simulateUserInteraction();
    
    // โฟกัสที่ input ทันที
    focusSearchInput();
    
    // ขอข้อมูล IP จาก server
    socket.emit('getServerIP');
    
    // โหลดเสียงล่วงหน้า
    preloadSound();
    
    // เริ่มตัวจับเวลา
    resetTimers();
});

// เพิ่ม event listener สำหรับการออกจากหน้า
window.addEventListener('beforeunload', () => {
    const screensaver = document.querySelector('.screensaver');
    if (screensaver) {
        const video = screensaver.querySelector('video');
        if (video) {
            video.pause();
            video.currentTime = 0;
        }
    }
    clearTimeout(inactivityTimer);
    clearTimeout(screensaverTimer);
});

// เพิ่ม event listener สำหรับการซ่อนหน้าต่าง
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        const screensaver = document.querySelector('.screensaver');
        if (screensaver) {
            const video = screensaver.querySelector('video');
            if (video) {
                video.pause();
                video.currentTime = 0;
            }
        }
    }
});