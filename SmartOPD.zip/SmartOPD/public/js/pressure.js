const socket = io();
let startSound, completeSound;

// ฟังก์ชันสำหรับโหลดเสียง
function loadSounds() {
    startSound = new Audio('/sounds/วัดอุณหภูมิเรียบร้อย.mp3');
    completeSound = new Audio('/sounds/2.mp3');
    highPressureSound = new Audio('/sounds/ความดันสูง.mp3');
    dangerPressureSound = new Audio('/sounds/ความดันอันตราย.mp3');
    // Preload เสียง
    startSound.load();
    completeSound.load();
    highPressureSound.load();
    dangerPressureSound.load();
}

// เพิ่ม event listener เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    loadSounds();
    
    // เลิ่มตัวแปรสำหรับเก็บ timer
    let inactivityTimer;
    
    // ฟังก์ชันรีเซ็ตการนับเวลา
    const resetInactivityTimer = () => {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            // รีเซ็ตค่าใน JSON
            socket.emit('resetReadings');
            // กลับไปหน้าหลัก
            window.location.href = '/';
        }, 90000); // 1.30 นาที = 90000 มิลลิวินาที
    };

    // เริ่มนับเวลาเมื่อโหลดหน้า
    resetInactivityTimer();

    // รีเซ็ตเวลาเมื่อมีการทำกิจกรรม
    document.addEventListener('mousemove', resetInactivityTimer);
    document.addEventListener('keypress', resetInactivityTimer);
    document.addEventListener('click', resetInactivityTimer);
    document.addEventListener('touchstart', resetInactivityTimer);

    // เล่นเสียงเริ่มต้นที่วินาทีที่ 2.3
    setTimeout(() => {
        startSound.currentTime = 2.1;
        const playPromise = startSound.play();
        
        if (playPromise !== undefined) {
            playPromise.then(_ => {
                console.log('เริ่มเล่นเสียง');
            })
            .catch(error => {
                console.log('ไม่สามารถเล่นเสียงได้:', error);
            });
        }
    }, 1000); // รอ 1 วินาทีก่นเล่นเสียง

    // เพิ่ม event listener สำหรับปุ่มข้าม
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.addEventListener('click', () => {
            socket.emit('getDisplayConfig', (config) => {
                const enabledPages = config.order.filter(page => config.enabled[page]);
                const lastPage = enabledPages[enabledPages.length - 1];
                const currentPage = 'pressure';
  // อัพเดทค่าอุณหภูมิเป็น 0 ใน JSON
                socket.emit('updateReadings', {
                    type: 'pressure',
                    value: {
                        systolic: 0,
                        diastolic: 0,
                        pulse: 0
                    },
                    currentPage: 'pressure'
});

                if (currentPage === lastPage) {
                    window.location.href = '/thankyou';
                } else {
                    window.location.href = '/next-page?from=pressure';
                }
            });
        });
    }

    const patient = JSON.parse(localStorage.getItem('currentPatient') || '{}');
    if (patient.hn && patient.vn) {
        // เริ่ม session
        socket.emit('initSession', {
            hn: patient.hn,
            vn: patient.vn
        });
        
        socket.emit('getCurrentReadings', 
            { hn: patient.hn, vn: patient.vn },
            (readings) => {
                console.log('=== ข้อมูลที่เก็บไว้ ===');
                console.log('อุณหภูมิ:', readings?.temperature);
                console.log('ความดัน:', readings?.pressure);
                console.log('BMI:', readings?.bmi);
                console.log('ข้อมูลผู้ป่วย:', readings?.patientInfo);
                console.log('=====================');
            }
        );
    }
});

// รับค่าความดันจาก socket
socket.on('pressure', async (data) => {
    if (data && data.systolic && data.diastolic && data.pulse) {
        // อัพเดทค่าที่แสดง
        const systolicValue = document.querySelector('.vital-item:nth-child(1) .value');
        const diastolicValue = document.querySelector('.vital-item:nth-child(3) .value');
        const pulseValue = document.querySelector('.vital-item:nth-child(5) .value');
        const systolicColor = await getSystolicColor(data.systolic);
        const diastolicColor = await getDiastolicColor(data.diastolic);
        const pulseColor = await getPulseColor(data.pulse);
        if (systolicValue){
            systolicValue.textContent = data.systolic;  
            systolicValue.style.color = systolicColor;
        }
        if (diastolicValue){
            diastolicValue.textContent = data.diastolic;
            diastolicValue.style.color = diastolicColor;
        }
        if (pulseValue) {
            pulseValue.textContent = data.pulse;
            pulseValue.style.color = pulseColor;
        }
        console.log(data.systolic, data.diastolic);
        
        // รอให้ได้ค่าสุดท้ายก่อนแสดงผล
        setTimeout(async () => {
            const pressureLevel = await getPressure(data.systolic, data.diastolic);
            
            // ลดความสว่างของทุก segment
            document.querySelectorAll('.segment').forEach(segment => {
                segment.style.opacity = '0.3';
            });

            // แสดง segment ที่ตรงกับระดับความดัน
            let targetSegment;
            switch(pressureLevel) {
                case 'low':
                    targetSegment = document.querySelector('.segment-low');
                    break;
                case 'normal':
                    targetSegment = document.querySelector('.segment-normal');
                    break;
                case 'high':
                    targetSegment = document.querySelector('.segment-high');
                    break;
                case 'danger':
                    targetSegment = document.querySelector('.segment-danger');
                    break;
            }

            if (targetSegment) {
                targetSegment.style.opacity = '1';
                targetSegment.style.transition = 'opacity 0.5s ease';
            }
        }, 1000); // รอ 1 วินาที

        // เล่นเสียงเมื่อวัดเสร็จ
        const systolicValue1 = parseInt(data.systolic);
        const diastolicValue1 = parseInt(data.diastolic);
        
        // ดึงค่า config จาก server
        fetch('/api/color-settings')
            .then(response => response.json())
            .then(data => {
                const config = data.config;
                // เลือกเสียงที่จะเล่นตามระดับความดัน
                let soundToPlay;
                if (systolicValue1 >= 160 || diastolicValue1 >= 100) {
                    soundToPlay = dangerPressureSound;
                } else if (systolicValue1 >= config.sys.high || diastolicValue1 >= config.dia.high) {
                    soundToPlay = highPressureSound;
                } else {
                    soundToPlay = completeSound;
                }

                const playPromise = soundToPlay.play();
                if (playPromise !== undefined) {
                    playPromise.then(_ => {
                        // ตรวจสอบค่าความดัน systolic และสั่งงาน relay
                        if (systolicValue1 < 160) {
                            socket.emit('controlRelay', { 
                                relay: 1,
                                action: 'on'
                            });
                        } else {
                            socket.emit('controlRelay', { 
                                relay: 2,
                                action: 'on'
                            });
                        }
                        
                        // รอให้เสียงเล่นจบก่อนเริ่มนับถอยหลัง
                        soundToPlay.addEventListener('ended', () => {
                            soundToPlay.currentTime = 0;
                            setTimeout(() => {
                                socket.emit('controlRelay', {
                                    relay: 1,
                                    action: 'off'
                                });
                                socket.emit('controlRelay', {
                                    relay: 2,
                                    action: 'off'
                                });
                            }, 2500);
                            startCountdown();
                        });
                        
                    }).catch(error => {
                        console.log('ไม่สามารถเล่นเสียงได้:', error);
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching config:', error);
            });
           

        const patient = JSON.parse(localStorage.getItem('currentPatient') || '{}');
        // ส่งข้อมูลเพื่อบันทึก
        socket.emit('updateReadings', {
            type: 'pressure',
            value: {
                systolic: data.systolic,
                diastolic: data.diastolic,
                pulse: data.pulse
            },
            hn: patient.hn,
            vn: patient.vn,
            currentPage: 'pressure'
        });
      
       
    }
});

// เพิ่ม handler สำหรับรับ error จาก relay
socket.on('relayError', (error) => {
    console.error('Relay error:', error.message);
});

// เพิ่มฟังก์ชันสำหรับแสดงการนับถอยหลัง
function startCountdown() {
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.style.display = 'none';
    }

    let countdown = 3;
    const countdownDiv = document.createElement('div');
    countdownDiv.className = 'text-center mt-3';
    
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const nextPage = enabledPages.find(page => 
            config.enabled[page] === true && 
            ["bmi"].includes(page)
        );
        
        const nextPageText = nextPage === 'bmi' ? 'ชั่งน้ำหนัก' : 'ขอบคุณ';
        
        countdownDiv.innerHTML = `<h5>กำลังไปหน้า${nextPageText}ในอีก ${countdown} วินาที...</h5>`;
        document.querySelector('.reading-box').appendChild(countdownDiv);

        const countdownInterval = setInterval(() => {
            countdown--;
            countdownDiv.innerHTML = `<h5>กำลังไปหน้า${nextPageText}ในอีก ${countdown} วินาที...</h5>`;
            
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                if (nextPage) {
                    window.location.href = '/next-page?from=pressure';
                } else {
                    window.location.href = '/thankyou';
                }
            }
        }, 1000);
    });
}

function getPressure(systolic, diastolic) {
    const systolicValue = parseFloat(systolic);
    const diastolicValue = parseFloat(diastolic);
    
    if (isNaN(systolicValue) || isNaN(diastolicValue)) {
        return '#000000';
    }

    return fetch('/api/color-settings')
        .then(response => {
            if (!response.ok) {
                throw new Error('ไม่สามารถโหลด config ได้');
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.config || !data.config.sys || !data.config.dia) {
                throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
            }
            
            const config = data.config;
            console.log('Systolic:', systolicValue);
            if(systolicValue >= 160 || diastolicValue >= 100){
                return 'danger';
            }
            else if(systolicValue <= config.sys.low || diastolicValue <= config.dia.low){
                return 'low';
            }else if(systolicValue >= config.sys.high || diastolicValue >= config.dia.high){
                return 'high';
            }else{
                return 'normal';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            return '#192586';
        });
}

function getSystolicColor(systolic) {
    const systolicValue = parseFloat(systolic);
    
    if (isNaN(systolicValue)) {
        return '#000000';
    }

    return fetch('/api/color-settings')
        .then(response => {
            if (!response.ok) {
                throw new Error('ไม่สามารถโหลด config ได้');
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.config || !data.config.sys || !data.config.dia) {
                throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
            }
            
            const config = data.config;
            console.log('Systolic:', systolicValue);
            if(systolicValue <= config.sys.low){
                return config.sys.lowColor;
            }else if(systolicValue >= config.sys.high){
                return config.sys.highColor;
            }else{
                return config.sys.normalColor;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            return '#192586';
        });
}
function getDiastolicColor(diastolic) {
    const diastolicValue = parseFloat(diastolic);
    
    if (isNaN(diastolicValue)) {
        return '#000000';
    }

    return fetch('/api/color-settings')
        .then(response => {
            if (!response.ok) {
                throw new Error('ไม่สามารถโหลด config ได้');
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.config || !data.config.sys || !data.config.dia) {
                throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
            }
            
            const config = data.config;
            console.log('Diastolic:', diastolicValue);
            if(diastolicValue <= config.dia.low){
                return config.dia.lowColor;
            }else if(diastolicValue >= config.dia.high){
                return config.dia.highColor;
            }else{
                return config.dia.normalColor;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            return '#192586';
        });
}
function getPulseColor(pulse) {
    const pulseValue = parseFloat(pulse);
    
    if (isNaN(pulseValue)) {
        return '#000000';
    }

    return fetch('/api/color-settings')
        .then(response => {
            if (!response.ok) {
                throw new Error('ไม่สามารถโหลด config ได้');
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.config || !data.config.pulse) {
                throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
            }
            
            const config = data.config;
            console.log('Pulse:', pulseValue);
            return config.pulse.normalColor;
           
        })
        .catch(error => {
            console.error('Error:', error);
            return '#192586';
        });
}
// เพิ่มฟังก์ชันตรวจสอบระดับความดัน
function checkPressureLevel(systolic, diastolic) {
    // ขอข้อมูลการตั้งค่าสีจาก server
    return new Promise((resolve) => {
        socket.emit('getColorSettings', async () => {
            socket.once('colorSettings', (colorConfig) => {
                const sys = colorConfig.sys;
                const dia = colorConfig.dia;
               
                if (systolic < sys.low || diastolic < dia.low) {
                    resolve({ 
                        level: 'low', 
                        text: 'ต่ำ', 
                        color: sys.lowColor 
                    });
                } else if (systolic < sys.high && diastolic < dia.high) {
                    resolve({ 
                        level: 'normal', 
                        text: 'ปกติ', 
                        color: sys.normalColor 
                    });
                } else {
                    resolve({ 
                        level: 'high', 
                        text: 'สูง', 
                        color: sys.highColor 
                    });
                }
            });
        });
    });
}

// เพิ่ม event listener สำหรับการออกจากหน้า
window.addEventListener('beforeunload', () => {
    // ปิด relay ทั้งสองตัวเมื่อออกจากหน้า
    socket.emit('controlRelay', {
        relay: 1,
        action: 'off'
    });
    socket.emit('controlRelay', {
        relay: 2,
        action: 'off'
    });
});

// เพิ่ม event listener สำหรับการซ่อนหน้าต่าง
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // ปิด relay ทั้งสองตัวเมื่อซ่อนหน้าต่าง
        socket.emit('controlRelay', {
            relay: 1,
            action: 'off'
        });
        socket.emit('controlRelay', {
            relay: 2,
            action: 'off'
        });
    }
}); 