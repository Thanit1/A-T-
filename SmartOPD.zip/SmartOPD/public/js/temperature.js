const socket = io();

// เพิ่มฟังก์ชันสำหรับแสดงการนับถอยหลัง
function startCountdown() {
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.style.display = 'none';
    }
    
    let countdown = 3;
    const countdownDiv = document.getElementById('measurementStatus');
    // countdownDiv.className = 'text-center mt-3';
    
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const nextPage = enabledPages.find(page => 
            config.enabled[page] === true && 
            ["pressure", "bmi"].includes(page)
        );
        
        const nextPageText = nextPage === 'pressure' ? 'วัดความดัน' : 
                           nextPage === 'bmi' ? 'ชั่งน้ำหนัก' : 'หน้าหลัก';
        
        countdownDiv.innerHTML = `<h5>กำลังไปหน้า${nextPageText}ในอีก ${countdown} วินาที...</h5>`;
        // document.querySelector('.card-body').appendChild(countdownDiv);
        
        const countdownInterval = setInterval(() => {
            countdown--;
            countdownDiv.innerHTML = `<h5>กำลังไปหน้า${nextPageText}ในอีก ${countdown} วินาที...</h5>`;
            
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                window.location.href = '/next-page?from=temperature';
            }
        }, 1000);
    });
}

// เพิ่มฟังก์ชันสำหรับ redirect
function redirectToPressure() {
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const lastPage = enabledPages[enabledPages.length - 1];
        const currentPage = 'temperature';

        if (currentPage === lastPage) {
            window.location.href = '/thankyou';  // แก้ตรงนี้ให้ไปหน้า thankyou
        } else {
            // ตรวจสอบลำดับการแสดงผลจาก config.order (คงเดิม)
            const nextPage = config.order.find(page => 
                config.enabled[page] === true && 
                ["pressure", "bmi"].includes(page)
            );
            
            if (nextPage) {
                window.location.href = `/${nextPage}`;
            } else {
                window.location.href = '/';
            }
        }
    });
}

// เพิ่มตรงส่วนบนของไฟล์
const beforeMeasureSound = new Audio('/sounds/ก่อนวัด.mp3');
const measureCompleteSound = new Audio('/sounds/วัดอุณหภูมิเรียบร้อย.mp3');

function playMeasureCompleteSound() {
    measureCompleteSound.play();
    
    // หยุดเสียงหลังจาก 2.3 วินาที
    setTimeout(() => {
        measureCompleteSound.pause();
        measureCompleteSound.currentTime = 0;
    }, 2100);
}

// แก้ไขฟังก์ชัน getTemperatureColor
function getTemperatureColor(temp) {
    const temperature = parseFloat(temp);
    
    if (isNaN(temperature)) {
        return '#000000';
    }

    return fetch('/api/color-settings')
        .then(response => {
            if (!response.ok) {
                throw new Error('ไม่สามารถโหลด config ได้');
            }
            return response.json();
        })
        .then(data => {
            if (!data.success || !data.config || !data.config.temp) {
                throw new Error('รูปแบบข้อมูลไม่ถูกต้อง');
            }
            
            const config = data.config;
            console.log('Temperature:', temperature);
            console.log('Threshold:', config.temp.feverThreshold);
            
            return temperature <= config.temp.feverThreshold 
                ? config.temp.normalColor 
                : config.temp.feverColor;
        })
        .catch(error => {
            console.error('Error:', error);
            return '#192586';
        });
}


// แก้ไข socket.on('temperature')
socket.on('temperature', async (temp) => {
    const tempElement = document.getElementById('temperature');
    const statusElement = document.getElementById('statusDisplay');
    
    if (temp !== undefined && temp !== null) {
        tempElement.style.color = await getTemperatureColor(temp);
        tempElement.textContent = temp + '°c';
        
    
        const patient = JSON.parse(localStorage.getItem('currentPatient') || '{}');
        // ส่งข้อมูลเพื่อบันทึก
        socket.emit('updateReadings', {
            type: 'temperature',
            value: temp,
            hn: patient.hn,
            vn: patient.vn,
            currentPage: 'temperature'
        });
        
        playMeasureCompleteSound();
        startCountdown();
    }
});

// เพิ่มการจัดการเมื่อการวัดเสร็จสมบูรณ์
socket.on('temperatureMeasurementComplete', () => {
    // เล่นเสียงเมื่อวัดเสร็จ
    playMeasureCompleteSound();
    // ซ่อนปุ่มไปหน้าถัดไป (ถ้ามี)
    const nextButton = document.querySelector('.next-btn');
    if (nextButton) {
        nextButton.style.display = 'none';
    }
    // เริ่มนับถอยหลัง
    startCountdown();
});

// เพิ่มการจัดการ error
socket.on('temperatureError', (error) => {
    const tempElement = document.getElementById('temperature');
    tempElement.textContent = 'Error';
    tempElement.style.color = 'red';
    console.error('Temperature measurement error:', error);
});

// เรียกใช้เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    // Preload เสียง
    beforeMeasureSound.load();
    measureCompleteSound.load();
    
    // เล่นเสียงก่อนวัดตั้งแต่วินาทีที่ 2.5
    beforeMeasureSound.currentTime = 2.5;
    beforeMeasureSound.play().catch(error => {
        console.log('ไม่สามารถเล่นเสียงได้:', error);
    });
     // เลิ่มตัวแปรสำหรับเก็บ timer
     let inactivityTimer;
    
     // ฟังก์ชันรีเซ็ตการนับเวลา
     const resetInactivityTimer = () => {
         clearTimeout(inactivityTimer);
         inactivityTimer = setTimeout(() => {
             // รีเซ็ตค่าใน JSON
             socket.emit('resetReadings');
             // กลับไปหน้าหลัก
             window.location.href = '/';
         }, 60000); // 1 นาที = 60000 มิลลิวินาที
     };
 
     // เริ่มนับเวลาเมื่อโหลดหน้า
     resetInactivityTimer();
 
     // รีเซ็ตเวลาเมื่อมีการทำกิจกรรม
     document.addEventListener('mousemove', resetInactivityTimer);
     document.addEventListener('keypress', resetInactivityTimer);
     document.addEventListener('click', resetInactivityTimer);
     document.addEventListener('touchstart', resetInactivityTimer);
 

    // เพิ่ม event listener สำหรับปุ่ม้าม
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.addEventListener('click', () => {
            // หยุดเสียงที่กำลังเล่นอยู่ (ถ้ามี)
            beforeMeasureSound.pause();
            beforeMeasureSound.currentTime = 0;
            measureCompleteSound.pause();
            measureCompleteSound.currentTime = 0;

            // อัพเดทค่าอุณหภูมิเป็น 0 ใน JSON
            socket.emit('updateReadings', {
                type: 'temperature',
                value: 0,
                currentPage: 'temperature'
            });
            
            // redirect ไปหน้าความดัน
            redirectToPressure();
        });
    }

    const patient = JSON.parse(localStorage.getItem('currentPatient') || '{}');
    if (patient.hn && patient.vn) {
        // เริ่ม session
        socket.emit('initSession', {
            hn: patient.hn,
            vn: patient.vn
        });
        
        socket.emit('getCurrentReadings', 
            { hn: patient.hn, vn: patient.vn },
            (readings) => {
                console.log('=== ข้อมูลที่เก็บไว้ ===');
                console.log('อุณหภูมิ:', readings?.temperature);
                console.log('ความดัน:', readings?.pressure);
                console.log('BMI:', readings?.bmi);
                console.log('ข้อมูลผู้ป่วย:', readings?.patientInfo);
                console.log('=====================');
            }
        );
    }
}); 