const socket = io();

// ตัวแปรสำหรับจัดการการค้นหา
let isProcessing = false;
let lastSearchValue = '';
let debounceTimer = null;

// ตัวแปรสำหรับจัดการ Modal
let alertModal;
let reconnectModal;
let currentReconnectType = null;
let errorModal;

// เพิ่มตัวแปรสำหรับเก็บสถานะก่อนหน้า
let previousStatus = {
    pressure: { connected: false },
    temp: { connected: false }
};

// เพิ่มตัวแปร connectionStatus
let connectionStatus = {
    pressure: { connected: false },
    temp: { connected: false }
};

// เพิ่มตัวแปรเก็บการตั้งค่าสี
let colorSettings = null;

// เพิ่มตัวแปรสำหรับจัดการ inactivity
let inactivityTimer;
let screenSaverTimer;
const RESET_TIMEOUT = 30 * 1000;          // 30 วินาที
const SCREENSAVER_TIMEOUT = 60 * 1000;    // 1 นาที

// เพิ่มตัวแปรสำหรับเก็บสถานะการ interact
let hasUserInteracted = false;

// เพิ่มตัวแปรสำหรับจัดการวิดีโอ
let videoFiles = [];
let currentVideoIndex = 0;

// เพิ่มฟังก์ชันโหลดรายการวิดีโอ
async function loadVideos() {
    try {
        const response = await fetch('/api/videos');
        if (!response.ok) throw new Error('Failed to load videos');
        videoFiles = await response.json();
        console.log('Loaded videos:', videoFiles);
        if (videoFiles.length > 0) {
            shuffleVideos();
        } else {
            console.warn('No videos found in directory');
        }
    } catch (error) {
        console.error('Error loading videos:', error);
    }
}

// เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    try {
        // รีเซ็ตค่าที่แสดง
        document.getElementById('systolic').textContent = '-';
        document.getElementById('diastolic').textContent = '-';
        document.getElementById('pulse').textContent = '-';
        document.getElementById('temperature').textContent = '-';
        
        // ตรวจสอบว่า element มีอยู่จริงก่อนสร้าง Modal
        const alertModalElement = document.getElementById('alertModal');
        const reconnectModalElement = document.getElementById('reconnectModal');
        const errorModalElement = document.getElementById('errorModal');
        
        if (alertModalElement) {
            alertModal = new bootstrap.Modal(alertModalElement);
        }
        if (reconnectModalElement) {
            reconnectModal = new bootstrap.Modal(reconnectModalElement);
        }
        if (errorModalElement) {
            errorModal = new bootstrap.Modal(errorModalElement);
        }
        
        // เริ่มการตรวจสอบการเชื่อมต่อ
        startConnectionCheck();
        
        // โฟกัที่ช่องค้นหา
        focusSearchInput();

        // ลบ event listeners เดิมที่ซ้ำซ้อน
        const activityEvents = [
            'mousedown', 'mousemove', 'keypress', 
            'scroll', 'touchstart', 'click', 'keydown',
            'focus', 'blur', 'change', 'input'
        ];

        // เพิ่ม event listener แบบรวม
        activityEvents.forEach(eventName => {
            document.addEventListener(eventName, () => {
                console.log('Activity detected:', eventName);
                if (inactivityTimer) clearTimeout(inactivityTimer);
                if (screenSaverTimer) clearTimeout(screenSaverTimer);
                
                // ซ่อน screensaver ถ้ากำลังแสดงอยู่
                const screenSaver = document.getElementById('screenSaver');
                if (screenSaver && screenSaver.style.display !== 'none') {
                    hideScreenSaver();
                }
                
                // ตั้ง timer ใหม่
                inactivityTimer = setTimeout(() => {
                    console.log('Resetting values due to inactivity');
                    resetAllValues();
                }, RESET_TIMEOUT);

                screenSaverTimer = setTimeout(() => {
                    console.log('Showing screensaver due to inactivity');
                    showScreenSaver();
                }, SCREENSAVER_TIMEOUT);
            });
        });

        // แก้ไข event listeners สำหรับการวัดค่า
        socket.on('temperature', (temp) => {
            console.log('Temperature reading:', temp);
            const tempElement = document.getElementById('temperature');
            if (temp !== undefined && temp !== null) {
                tempElement.textContent = temp;
                if (colorSettings?.temp?.color) {
                    tempElement.style.color = colorSettings.temp.color;
                }
            } else {
                tempElement.textContent = '-';
            }
            // รีเซ็ต timer หลังจากได้รับค่า
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (screenSaverTimer) clearTimeout(screenSaverTimer);
            hideScreenSaver();
            inactivityTimer = setTimeout(resetAllValues, RESET_TIMEOUT);
            screenSaverTimer = setTimeout(showScreenSaver, SCREENSAVER_TIMEOUT);
        });

        socket.on('pressure', (data) => {
            console.log('Pressure reading:', data);
            if (data && colorSettings) {
                const sysElement = document.getElementById('systolic');
                const diaElement = document.getElementById('diastolic');
                const prElement = document.getElementById('pulse');

                // ตรวจสอบว่าค่าที่ได้มาไม่ใช่ค่าว่าง
                if (data.systolic && data.diastolic && data.pulse) {
                    sysElement.textContent = data.systolic;
                    diaElement.textContent = data.diastolic;
                    prElement.textContent = data.pulse;

                    checkValueAndSetColor(data.systolic, 'sys', sysElement);
                    checkValueAndSetColor(data.diastolic, 'dia', diaElement);
                    checkValueAndSetColor(data.pulse, 'pr', prElement);

                    // เล่นเสียงเมื่อวัดความดันเสร็จ
                    document.getElementById('pressureCompleteSound').play();
                }
            }
            // รีเซ็ต timer หลังจากได้รับค่า
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (screenSaverTimer) clearTimeout(screenSaverTimer);
            hideScreenSaver();
            inactivityTimer = setTimeout(resetAllValues, RESET_TIMEOUT);
            screenSaverTimer = setTimeout(showScreenSaver, SCREENSAVER_TIMEOUT);
        });

        // เพิ่ม event listeners สำหรับการรีเซ็ตเวลา
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, () => {
                console.log('User activity detected:', event);
                resetInactivityTimer();
            });
        });

        // เพิ่ม event listeners สำหรับการวัดค่า
        socket.on('temperature', () => {
            console.log('Temperature reading detected');
            resetInactivityTimer();
        });
        
        socket.on('pressure', () => {
            console.log('Pressure reading detected');
            resetInactivityTimer();
        });

        // เริ่มนับเวลาครั้งแรก
        console.log('Starting initial timer');
        resetInactivityTimer();

        // กำหนด events สำหรับการ interact ครั้งแรก
        const userInteractionEvents = ['click', 'touchstart', 'keydown', 'mousemove'];
        
        // ฟังก์ชันจัดการการ interact
        function handleUserInteraction(event) {
            console.log('User interaction detected:', event.type);
            hasUserInteracted = true;
            
            // ถ้า screensaver กำลังเล่นอยู่ ให้เปิดเสียง
            const video = document.getElementById('screenSaverVideo');
            if (video && video.playing) {
                video.muted = false;
                video.volume = 1.0;
                console.log('Unmuted video after user interaction');
            }

            // รีเซ็ต timers
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (screenSaverTimer) clearTimeout(screenSaverTimer);
            
            // ซ่อน screensaver ถ้ากำลังแสดงอยู่
            const screenSaver = document.getElementById('screenSaver');
            if (screenSaver && screenSaver.style.display !== 'none') {
                hideScreenSaver();
            }
            
            // ตั้ง timer ใหม่
            inactivityTimer = setTimeout(() => {
                console.log('Resetting values due to inactivity');
                resetAllValues();
            }, RESET_TIMEOUT);

            screenSaverTimer = setTimeout(() => {
                console.log('Showing screensaver due to inactivity');
                showScreenSaver();
            }, SCREENSAVER_TIMEOUT);
        }

        // เพิ่ม event listeners
        userInteractionEvents.forEach(event => {
            document.addEventListener(event, handleUserInteraction);
        });

        // เตรียมระบบเสียง
        prepareAudio();

        // โหลดรายการวิดีโอ
        loadVideos();

    } catch (error) {
        console.error('Error in DOMContentLoaded:', error);
    }
});

// ฟังก์ชันสำหรับการค้นหา
function searchPatient(searchValue) {
    if (searchValue === lastSearchValue || isProcessing || !searchValue.trim()) {
        return;
    }

    isProcessing = true;
    lastSearchValue = searchValue;

    socket.emit('searchPatients', searchValue);

    setTimeout(() => {
        isProcessing = false;
    }, 1000);
}

// ฟังก์ชันสำหรับ focus input
function focusSearchInput() {
    const searchInput = document.getElementById('searchValue');
    searchInput.value = '';
    searchInput.focus();
    isProcessing = false;
    lastSearchValue = '';
}

// Event Listeners สำหรับการค้นหา
document.getElementById('searchValue').addEventListener('input', function(e) {
    const searchValue = e.target.value.trim();
    
    if (debounceTimer) {
        clearTimeout(debounceTimer);
    }
    
    if (searchValue.length >= 2) {
        debounceTimer = setTimeout(() => {
            searchPatient(searchValue);
        }, 300);
    }
});

document.getElementById('searchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const searchValue = document.getElementById('searchValue').value.trim();
    
    if (!searchValue) {
        alert('กรุณาระบุคำค้นหา');
        return;
    }
    
    searchPatient(searchValue);
});

// Event Listeners สำหรับการแสดงผลการค้นหา
socket.on('patientFound', (patient) => {
    displayPatient(patient);
    setTimeout(focusSearchInput, 500);
});

socket.on('patientNotFound', (message) => {
    const tbody = document.getElementById('patientList');
    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="text-center">${message}</td>
        </tr>
    `;
    setTimeout(focusSearchInput, 500);
});

// ฟังก์ชันแสดงข้อมูลคนไข
function displayPatient(patient) {
    const patientList = document.getElementById('patientList');
    patientList.innerHTML = '';
    
    if (!patient) {
        patientList.innerHTML = `
            <div class="list-group-item text-center">ไม่พบข้อมูล</div>
        `;
        return;
    }
    
    const birthDate = new Date(patient.thai_birthday);
    const thaiDate = birthDate.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    const item = document.createElement('div');
item.className = 'list-group-item mb-3 p-3 border rounded shadow-sm';
item.innerHTML = `
    
    <div class="text-center">
    <h3 class="mb-2">ชื่อ-สกุล: <span class="">${patient.patient_name || '-'}</span></h3>
    <h5 class="mb-1">
        HN: <span class="text-muted">${patient.hn || '-'}</span>
        <span class="mx-3">|</span>
        VN: <span class="text-muted">${patient.vn || '-'}</span>
    </h5>
    <h5 class="mb-0">
        อายุ: <span class="text-muted">${patient.age || '-'}</span> ปี
        <span class="mx-3">|</span>
        วันเกิด: <span class="text-muted">${thaiDate || '-'}</span>
    </h5>
</div>
`;
patientList.appendChild(item);

    // เล่นเสียงเมื่อค้นหาเจอผู้ป่วย
    document.getElementById('searchCompleteSound').play();
}

// ฟังก์ชันดูข้อมูลคนไข้
function viewPatient(hn) {
    window.location.href = `/patient/${hn}`;
}

// การจัดการการเชื่อมต่อ
function startConnectionCheck() {
    setInterval(() => {
        socket.emit('getConnectionStatus');
    }, 2000);
}

socket.on('connectionStatus', (status) => {
    console.log('Connection status received:', status);
    connectionStatus = status;
    updateConnectionStatus(status);
});

function updateConnectionStatus(status) {
    const pressureStatus = document.getElementById('pressureStatus');
    const tempStatus = document.getElementById('tempStatus');

    // ตรวจสอบการเปลี่ยนแปลงสถานะ pressure
    if (status.pressure?.connected) {
        pressureStatus.textContent = 'เชื่อมต่อแล้ว';
        pressureStatus.className = 'badge bg-success';
        previousStatus.pressure.connected = true;
        // ปิด Modal ถ้ากำลังแสดงอยู่
        if (document.querySelector('#errorModal.show')) {
            const currentErrorCode = document.getElementById('errorCode').textContent;
            if (currentErrorCode.includes('PRESSURE')) {
                const modalInstance = bootstrap.Modal.getInstance(document.getElementById('errorModal'));
                if (modalInstance) {
                    modalInstance.hide();
                }
            }
        }
    } else {
        pressureStatus.textContent = 'ไม่ได้เชื่อมต่อ';
        pressureStatus.className = 'badge bg-secondary';
        if (previousStatus.pressure.connected) {
            showErrorModal('pressure');
        }
        previousStatus.pressure.connected = false;
    }

    // ตรวจสอบการเปลี่ยนแปลงสถานะ temp
    if (status.temp?.connected) {
        tempStatus.textContent = 'เชื่อมต่อแล้ว';
        tempStatus.className = 'badge bg-success';
        previousStatus.temp.connected = true;
        // ปิด Modal ถ้ากำลังแสดงอยู่
        if (document.querySelector('#errorModal.show')) {
            const currentErrorCode = document.getElementById('errorCode').textContent;
            if (currentErrorCode.includes('TEMP')) {
                const modalInstance = bootstrap.Modal.getInstance(document.getElementById('errorModal'));
                if (modalInstance) {
                    modalInstance.hide();
                }
            }
        }
    } else {
        tempStatus.textContent = 'ไม่ได้เชื่อมต่อ';
        tempStatus.className = 'badge bg-secondary';
        if (previousStatus.temp.connected) {
            showErrorModal('temp');
        }
        previousStatus.temp.connected = false;
    }
}

// อัพเดทค่าที่วัดได้
socket.on('temperature', (temp) => {
    const tempElement = document.getElementById('temperature');
    if (temp !== undefined && temp !== null) {
        tempElement.textContent = temp;
        if (colorSettings?.temp?.color) {
            tempElement.style.color = colorSettings.temp.color;
        }
       
    } else {
        tempElement.textContent = '-';
    }
});

socket.on('pressure', (data) => {
    if (data && colorSettings) {
        const sysElement = document.getElementById('systolic');
        const diaElement = document.getElementById('diastolic');
        const prElement = document.getElementById('pulse');

        // ตรวจสอบว่าค่าที่ได้มาไม่ใช่ค่าว่าง
        if (data.systolic && data.diastolic && data.pulse) {
            sysElement.textContent = data.systolic;
            diaElement.textContent = data.diastolic;
            prElement.textContent = data.pulse;

            checkValueAndSetColor(data.systolic, 'sys', sysElement);
            checkValueAndSetColor(data.diastolic, 'dia', diaElement);
            checkValueAndSetColor(data.pulse, 'pr', prElement);

            // เล่นเสียงเมื่อวัดความดันเสร็จ
            document.getElementById('pressureCompleteSound').play();
        }
    }
});

// การจัดการ card reader
socket.on('cardInserted', (data) => {
    const searchInput = document.getElementById('searchValue');
    searchInput.value = data.cid;
    searchPatient(data.cid);
});

// เิ่มฟังก์ชันแสดง error modal
function showErrorModal(type) {
    const deviceName = type === 'pressure' ? 'เครื่องวัดความดัน' : 'เครื่องวัดอุณหภูมิ';

    // ตรวจสอบว่าอุปกรณ์ยังไม่ไ้เชื่อมต่อจริงๆ
    if (!connectionStatus[type]?.connected) {
        const errorCodeText = `ERR_${type.toUpperCase()}_DISCONNECTED`;
        const errorMessageText = `การเชื่อมต่อกับ${deviceName}ถูกตัดขาด กรุณาตรวจสอบการเชื่อมต่อและทำตามคำแนะนำด้านล่าง`;

        document.getElementById('errorCode').textContent = errorCodeText;
        document.getElementById('errorMessage').textContent = errorMessageText;

        // สร้าง Modal instance ใหม่ทุกครั้ง
        const modalElement = document.getElementById('errorModal');
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.dispose();
        }
        const newModal = new bootstrap.Modal(modalElement);
        newModal.show();
    }
}

// เพิ่ม event listener สำหรับการปิด Modal
document.getElementById('errorModal').addEventListener('hidden.bs.modal', function () {
    const modalInstance = bootstrap.Modal.getInstance(this);
    if (modalInstance) {
        modalInstance.dispose();
    }
});

// เพิ่ม event listeners สำหรับการแจ้งเตือน
socket.on('portError', (data) => {
    console.log('Port error received:', data);
    const { type, code, message } = data;
    showErrorModal(type);
});

socket.on('portSuccess', (data) => {
    const { type } = data;
    // ปิด Modal ถ้าเชื่มต่อสำเร็จ
    const modalElement = document.getElementById('errorModal');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
        const currentErrorCode = document.getElementById('errorCode').textContent;
        if (currentErrorCode.includes(type.toUpperCase())) {
            modalInstance.hide();
        }
    }
});

// รับการตั้งค่าสี
socket.on('colorSettings', (settings) => {
    colorSettings = settings;
});

// ขอการั้งค่าสีเมื่อโหลดหน้า
socket.emit('getColorSettings');

// เพิ่ม event listener สำหรับการบันทึกข้อมูล
socket.on('dataSaved', (response) => {
    if (response.success) {
        showSaveModal('success', 'บันทึกข้อมูลสำเร็จ');
        setTimeout(() => {
            window.location.reload();
        }, 5000);
    } else {
        showSaveModal('error', response.message);
    }
});

// แก้ไขฟังก์ชัน showSaveModal เพื่อไม่ให้ลบ modal element ออกเมื่อปิด
function showSaveModal(type, message) {
    const modalHtml = `
        <div class="modal fade" id="saveNotificationModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <i class="bi ${type === 'success' ? 'bi-check-circle-fill text-success' : 'bi-x-circle-fill text-danger'}" style="font-size: 2rem;"></i>
                            </div>
                            <div>
                                <h5 class="mb-0">${message}</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // เพิ่ม modal ไปยัง body
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // หา modal element
    const modalElement = document.getElementById('saveNotificationModal');

    // สร้าง modal instance
    const modal = new bootstrap.Modal(modalElement);

    // แสดง modal
    modal.show();
    // ซ่อน modal หลังจาก 4 วินาที
    setTimeout(() => {
        modal.hide();
    }, 4000);
}

// เพิ่มฟังก์ชัน resetInactivityTimer
function resetInactivityTimer() {
    console.log('Resetting inactivity timer...');
    
    // ยกเลิก timer เดิม
    if (inactivityTimer) {
        clearTimeout(inactivityTimer);
        console.log('Cleared inactivity timer');
    }
    if (screenSaverTimer) {
        clearTimeout(screenSaverTimer);
        console.log('Cleared screensaver timer');
    }

    // ตั้ง timer ใหม่
    inactivityTimer = setTimeout(() => {
        console.log('Inactivity timeout reached - resetting values');
        resetAllValues();
    }, 30000); // 30 วินาที

    screenSaverTimer = setTimeout(() => {
        console.log('Screensaver timeout reached - showing screensaver');
        showScreenSaver();
    }, 60000); // 1 นาที
}

// แก้ไขส่วน DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        // ... existing code ...

        // เพิ่ม event listeners สำหรับการรีเซ็ตเวลา
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, () => {
                console.log('User activity detected:', event);
                resetInactivityTimer();
            });
        });

        // เพิ่ม event listeners สำหรับการวัดค่า
        socket.on('temperature', () => {
            console.log('Temperature reading detected');
            resetInactivityTimer();
        });
        
        socket.on('pressure', () => {
            console.log('Pressure reading detected');
            resetInactivityTimer();
        });

        // เริ่มนับเวลาครั้งแรก
        console.log('Starting initial timer');
        resetInactivityTimer();
    } catch (error) {
        console.error('Error in DOMContentLoaded:', error);
    }
});

// เพิ่มฟังก์ชัน resetAllValues
function resetAllValues() {
    console.log('Resetting all values...');
    try {
        // รีเซ็ตค่าการวัด
        const elementsToReset = {
            'systolic': '-',
            'diastolic': '-',
            'pulse': '-',
            'temperature': '-'
        };

        for (const [id, value] of Object.entries(elementsToReset)) {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
                console.log(`Reset ${id} to ${value}`);
            }
        }

        // รีเซ็ตการค้นหา
        const searchInput = document.getElementById('searchValue');
        if (searchInput) {
            searchInput.value = '';
            console.log('Cleared search input');
        }

        // ล้างผลการค้นหา
        const patientList = document.getElementById('patientList');
        if (patientList) {
            patientList.innerHTML = '';
            console.log('Cleared patient list');
        }

        // แสดงการแจ้งเตือน
        showAlert('รีเซ็ตค่าทั้งหมดแล้ว', 'info');
        
        // เริ่มนับเวลา screensaver ใหม่
        if (screenSaverTimer) clearTimeout(screenSaverTimer);
        screenSaverTimer = setTimeout(showScreenSaver, SCREENSAVER_TIMEOUT);
        
    } catch (error) {
        console.error('Error in resetAllValues:', error);
    }
}

// แก้ไขฟังก์ชันแสดงสถานะกรบันทึก
function showSavingStatus() {
    const statusElement = document.createElement('div');
    statusElement.className = 'position-fixed bottom-0 end-0 p-3';
    statusElement.style.zIndex = '5';
    statusElement.innerHTML = `
        <div class="toast show" role="alert">
            <div class="toast-header">
                <strong class="me-auto">กำลังบันทึก</strong>
            </div>
            <div class="toast-body">
                <div class="d-flex align-items-center">
                    <div class="spinner-border spinner-border-sm me-2" role="status">
                        <span class="visually-hidden">กำลังบันทึก...</span>
                    </div>
                    <span>กำลังบันทึกข้อมูล...</span>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(statusElement);

    // ลบ toast หลังจาก 3 วินาที
    setTimeout(() => {
        statusElement.remove();
    }, 2000);
}

// แก้ไขฟังก์ชันตรวจสอบคาและกำหนสี
function checkValueAndSetColor(value, type, element) {
    if (!colorSettings || !colorSettings[type]) return;
    
    // กรณีอุณหภูมิ ใช้แค่สีเดียว
    if (type === 'temp') {
        element.style.color = colorSettings.temp.color;
        return;
    }
    
    // กรณีอื่นๆ ใช้การตรวจสอบค่าและแจงเตือน
    const settings = colorSettings[type];
    if (value < settings.low) {
        element.style.color = settings.lowColor;
        showAlert(`ค่า${getTypeName(type)}ต่ำ`, 'warning');
    } else if (value > settings.high) {
        element.style.color = settings.highColor;
        showAlert(`ค่า${getTypeName(type)}สูง`, 'danger');
    } else {
        element.style.color = settings.normalColor;
    }
}

// เพิ่มฟังก์ชันแสดงการแจ้งเตือน
function showAlert(message, type) {
    if (!message) return; // ไม่แสดงถ้าไม่มีข้อความ
    
    try {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        const container = document.getElementById('toastContainer');
        if (container) {
            container.appendChild(toast);
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();
            
            // ลบ toast หลังจาก 5 วินาที
            setTimeout(() => {
                toast.remove();
            }, 5000);
        }
    } catch (error) {
        console.error('Error showing alert:', error);
    }
}

// เพิ่มฟังก์ชันแปลงชื่อประเภท
function getTypeName(type) {
    const types = {
        'temp': 'อุณหภูมิ',
        'sys': 'ความดันตัวบน',
        'dia': 'ความดันตัวล่าง',
        'pr': 'ชีพจร'
    };
    return types[type] || type;
}

// แก้ไขฟังก์ชัน showScreenSaver
function showScreenSaver() {
    console.log('Showing screensaver...');
    try {
        if (videoFiles.length === 0) {
            console.warn('No videos available');
            return;
        }

        const screenSaver = document.getElementById('screenSaver');
        const video = document.getElementById('screenSaverVideo');
        
        if (screenSaver && video) {
            screenSaver.style.display = 'block';
            
            // สลับวิดีโอ
            video.src = videoFiles[currentVideoIndex];
            
            // เพิ่ม event listener สำหรับเมื่อวิดีโอจบ
            video.onended = () => {
                console.log('Video ended, playing next video');
                currentVideoIndex = (currentVideoIndex + 1) % videoFiles.length;
                video.src = videoFiles[currentVideoIndex];
                video.play()
                    .then(() => {
                        video.muted = false;
                        video.volume = 1.0;
                        console.log('Next video started playing');
                    })
                    .catch(e => console.error('Error playing next video:', e));
            };
            
            // เล่นวิดีโอ
            video.play()
                .then(() => {
                    console.log('Video started successfully');
                    video.muted = false;
                    video.volume = 1.0;
                })
                .catch(error => {
                    console.error('Video play error:', error);
                    video.muted = true;
                    video.play().then(() => {
                        console.log('Video playing muted');
                        if (hasUserInteracted) {
                            video.muted = false;
                            video.volume = 1.0;
                        }
                    });
                });
        }
    } catch (error) {
        console.error('Error in showScreenSaver:', error);
    }
}

// แก้ไขฟังก์ชัน hideScreenSaver
function hideScreenSaver() {
    console.log('Hiding screensaver...');
    try {
        const screenSaver = document.getElementById('screenSaver');
        if (screenSaver) {
            screenSaver.style.display = 'none';
            const video = document.getElementById('screenSaverVideo');
            if (video) {
                video.pause();
                video.currentTime = 0;
                video.muted = true;
            }
        }
    } catch (error) {
        console.error('Error in hideScreenSaver:', error);
    }
}

// แก้ไขฟังก์ชันแสดง error
function showError(error) {
    console.error('Error:', error);
    const message = error?.message || 'เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ';
    showAlert(message, 'danger');
}

// เพิ่มฟังก์ชันสำหรับเตรียมการเล่นเสียง
function prepareAudio() {
    console.log('Preparing audio...');
    const video = document.getElementById('screenSaverVideo');
    if (video) {
        // ตั้งค่าเสียงเริ่มต้น
        video.muted = false;
        video.volume = 1.0;
        
        // เพิ่ม event listener สำหรับตรวจสอบการเล่นเสียง
        video.addEventListener('play', () => {
            console.log('Video play event triggered');
            // พยายามเปิดเสียงเมื่อวิดีโอเริ่มเล่น
            video.muted = false;
            video.volume = 1.0;
        });
    }
}

// เพิ่ม property สำหรับตรวจสอบสถานะการเล่นวิดีโอ
Object.defineProperty(HTMLMediaElement.prototype, 'playing', {
    get: function() {
        return !!(this.currentTime > 0 && !this.paused && !this.ended && this.readyState > 2);
    }
});
  