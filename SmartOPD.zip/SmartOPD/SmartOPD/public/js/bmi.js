const socket = io();

document.addEventListener('DOMContentLoaded', function() {
    // สร้าง Audio object
    const audio = new Audio('/sounds/ชั่งน้ำหนัก.mp3');
    
    // ตั้งค่าระดับเสียง
    audio.volume = 0.8;
    
    // ตั้งค่าให้เริ่มเล่นที่วินาทีที่ 2.5
    audio.currentTime = 2.5;
    
    // เล่นเสียงทันทีที่โหลดหน้าเสร็จ
    audio.play().catch(error => {
        console.error('Error playing audio:', error);
    });
 // เลิ่มตัวแปรสำหรับเก็บ timer
 let inactivityTimer;
    
 // ฟังก์ชันรีเซ็ตการนับเวลา
 const resetInactivityTimer = () => {
     clearTimeout(inactivityTimer);
     inactivityTimer = setTimeout(() => {
         // รีเซ็ตค่าใน JSON
         socket.emit('resetReadings');
         // กลับไปหน้าหลัก
         window.location.href = '/';
     }, 90000); // 1.30 นาที = 90000 มิลลิวินาที
 };

 // เริ่มนับเวลาเมื่อโหลดหน้า
 resetInactivityTimer();

 // รีเซ็ตเวลาเมื่อมีการทำกิจกรรม
 document.addEventListener('mousemove', resetInactivityTimer);
 document.addEventListener('keypress', resetInactivityTimer);
 document.addEventListener('click', resetInactivityTimer);
 document.addEventListener('touchstart', resetInactivityTimer);


});

function calculateBMI(weight, height) {
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters)).toFixed(1);
}

function getBMIStatus(bmi) {
    if (bmi < 18.5) {
        return { text: 'น้ำหนักน้อย', color: '#17a2b8', segment: 'low' };
    } else if (bmi < 25) {
        return { text: 'ปกติ', color: '#28a745', segment: 'normal' };
    } else if (bmi < 30) {
        return { text: 'น้ำหนักเกิน', color: '#ffc107', segment: 'high' };
    } else {
        return { text: 'อ้วน', color: '#dc3545', segment: 'danger' };
    }
}

// เพิ่มฟังก์ชันสำหรับ animation
function updateValue(element, value, duration = 1000) {
    const startValue = parseFloat(element.textContent) || 0;
    const endValue = parseFloat(value);
    const increment = (endValue - startValue) / (duration / 16);
    let currentValue = startValue;

    const animate = () => {
        currentValue += increment;
        if ((increment > 0 && currentValue >= endValue) || 
            (increment < 0 && currentValue <= endValue)) {
            element.textContent = endValue;
            return;
        }
        element.textContent = currentValue.toFixed(1);
        requestAnimationFrame(animate);
    };

    animate();
}

socket.on('weight_height', (data) => {
    console.log('Received weight_height data:', data);

    // แก้ไขเงื่อนไขให้แสดงค่าแม้จะมีแค่ค่าใดค่าหนึ่ง
    if (data.weight || data.height) {
        // เล่นเสียงเมื่อได้รับค่า
        const audio = new Audio('/sounds/น้ำหนัก.mp3');
        audio.volume = 0.8;
        audio.play().catch(error => {
            console.error('Error playing audio:', error);
        });

        const weightElement = document.querySelector('.vital-container .vital-item:nth-child(1) .value');
        const heightElement = document.querySelector('.vital-container .vital-item:nth-child(3) .value');
        const bmiElement = document.querySelector('.vital-container .vital-item:nth-child(5) .value');

        console.log('Elements found:', {
            weightElement,
            heightElement,
            bmiElement
        });

        // อัพเดทค่าด้ำหนัก (ถ้ามี)
        if (data.weight && weightElement) {
            console.log('Updating weight:', data.weight);
            updateValue(weightElement, data.weight);
        }

        // อัพเดทค่าส่วนสูง (ถ้ามี)
        if (data.height && heightElement) {
            console.log('Updating height:', data.height);
            updateValue(heightElement, data.height);
        }

        // คำนวณและแสดง BMI เฉพาะเมื่อมีทั้งน้ำหนักและส่วนสูง
        if (data.weight && data.height && bmiElement) {
            const bmi = calculateBMI(data.weight, data.height);
            console.log('Calculated BMI:', bmi);

            setTimeout(() => {
                updateValue(bmiElement, bmi);
            }, 1000);

            // แสดงสถานะ BMI ในแถบสี
            const bmiStatus = getBMIStatus(bmi);
            
            // รีเซ็ตความโปร่งใสของทุกเซกเมนต์
            document.querySelectorAll('.segment').forEach(segment => {
                segment.style.opacity = '0.3';
            });

            // ไฮไลท์เซกเมนต์ที่เกี่ยวข้อง
            let segmentClass;
            switch(bmiStatus.segment) {
                case 'low':
                    segmentClass = 'segment-low';
                    break;
                case 'normal':
                    segmentClass = 'segment-normal';
                    break;
                case 'high':
                    segmentClass = 'segment-high';
                    break;
                case 'danger':
                    segmentClass = 'segment-danger';
                    break;
            }
            
            const activeSegment = document.querySelector(`.${segmentClass}`);
            if (activeSegment) {
                activeSegment.style.opacity = '1';
            }
// บันทึกข้อมูลผู้ป่วย
      
socket.emit('updateReadings', {
    type: 'bmi',
    value: {
        weight: data.weight || null,
        height: data.height || null,
        bmi: bmi
    },
    currentPage: 'bmi'
});

            // เริ่มนับถอยหลังไปหน้าถัดไป
            startCountdown();
        }

        
    }
});

function startCountdown() {
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.style.display = 'none';
    }

    let countdown = 3;
    const countdownDiv = document.createElement('div');
    countdownDiv.className = 'text-center mt-3';

    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const currentPageIndex = enabledPages.indexOf('bmi');
        const isLastPage = currentPageIndex === enabledPages.length - 1;

        countdownDiv.innerHTML = `<h5>กำลังไปหน้าถั��ไปในอีก ${countdown} วินาที...</h5>`;
        document.querySelector('.reading-box').appendChild(countdownDiv);

        const countdownInterval = setInterval(() => {
            countdown--;
            countdownDiv.innerHTML = `<h5>กำลังไปหน้าถัดไปในอีก ${countdown} วินาที...</h5>`;
            
            if (countdown <= 0) {
                clearInterval(countdownInterval);
                if (isLastPage) {
                    window.location.href = '/thankyou';
                } else {
                    window.location.href = '/next-page?from=bmi';
                }
            }
        }, 1000);
    });
}

document.getElementById('skipButton')?.addEventListener('click', () => {
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const currentPageIndex = enabledPages.indexOf('bmi');
        const isLastPage = currentPageIndex === enabledPages.length - 1;

        if (isLastPage) {
            window.location.href = '/thankyou';
        } else {
            window.location.href = '/next-page?from=bmi';
        }
    });
}); 