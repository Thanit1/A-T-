const { spawn } = require('child_process');
const path = require('path');

let server = null;

function startServer() {
    // สร้าง process ใหม่สำหรับรัน server.js
    server = spawn('node', [path.join(__dirname, 'server.js')], {
        stdio: 'inherit'
    });

    // จัดการเมื่อเซิฟเวอร์ปิด
    server.on('close', (code) => {
        if (code === 100) { // รหัสพิเศษสำหรับการรีสตาร์ท
            console.log('เซิฟเวอร์กำลังรีสตาร์ท...');
            startServer();
        }
    });

    // จัดการข้อผิดพลาด
    server.on('error', (err) => {
        console.error('เกิดข้อผิดพลาดในการรันเซิฟเวอร์:', err);
    });
}

// เริ่มต้นเซิฟเวอร์
startServer(); 